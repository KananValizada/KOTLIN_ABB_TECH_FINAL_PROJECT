package com.example.food_mood.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}